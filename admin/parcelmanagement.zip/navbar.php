<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<div id="main">
<div class="header">
<h1>CANTIKK<span>ATHOME</span></h1>
</div>
<div id="navbar">
<a><button class="openbtn" onclick="openNav()">☰ </button> <div class="right_area"></a>

    </div>
    <div class="topnav-right"><a><button class="logout_btn" > <a href="Admin_LogOut.php"> LogOut</a> </button> </a>
</div>
</div>
<div id="mySidebar" class="sidebar">
<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
<a href="index.php" ><i class="fa fa-fw fa-home"></i> Dashboard</a>
<a href="Admin_Profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
<a href="Admin_Categories.php"><i class="fa fa-fw fa-list"></i> Category</a>
<a href="Admin_Product.php"><i class="fa fa-fw fa-list"></i> Product</a>
<a href="Admin_Tutorial.php"><i class="fa fa-video-camera"></i> Tutorial</a>
<a href="Admin_Beautician.php"><i class="fa fa-fw fa-user"></i>Beautician</a>
<button class="dropdown-btn"><i class="fa fa-fw fa-calendar"></i> Consultation
  <i class="fa fa-caret-down"></i>
</button>
<div class="dropdown-container">
  <a href="Admin_Schedule.php"></i>Schedule</a>
  <a href="Admin_Consultation.php"></i>Appointment</a>
</div>
<a href="Admin_Orders.php"><i class="fa fa-fw fa-cart-arrow-down"></i> Order</a>
<button class="dropdown-btn"><i class="fa fa-credit-card"></i> Payment
  <i class="fa fa-caret-down"></i>
</button>
<div class="dropdown-container">
  <a href="Admin_Payment_Product.php"></i>Product</a>
  <a href="Admin_Payment_Consultation.php"></i>Consultation</a>
</div>
<a href="Admin_Customer.php"><i class="fa fa-address-book"></i> Customer</a>
<a href="Admin_Feedback.php"><i class="fas fa-comments"></i> Feedback</a>
</div>
